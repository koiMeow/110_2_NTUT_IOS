//
//  ViewController.swift
//  Simplified Calculator
//
//  Created by student on 2022/3/21.
//  Copyright © 2022年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var buttons: [UIButton]!
    
    var isProgressLabelEmpty:Bool = true
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        for button in buttons {
            button.layer.cornerRadius = 37.5
        }
        
        progressLabel.text = ""
        answer.text = "0"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var progressLabel: UILabel!
    @IBOutlet weak var answer: UILabel!
    
    @IBOutlet var numbers: [UIButton]!
    var floatingPoint:Bool = false
    @IBAction func inputNumbers(_ sender: UIButton) {
        
        resetBuutonColor()
        
        switch numbers.index(of: sender)! {
        case 0:
            progressLabel.text! += "1"
            break
        case 1:
            progressLabel.text! += "2"
            break
        case 2:
            progressLabel.text! += "3"
            break
        case 3:
            progressLabel.text! += "4"
            break
        case 4:
            progressLabel.text! += "5"
            break
        case 5:
            progressLabel.text! += "6"
            break
        case 6:
            progressLabel.text! += "7"
            break
        case 7:
            progressLabel.text! += "8"
            break
        case 8:
            progressLabel.text! += "9"
            break
        case 9:
            progressLabel.text! += "0"
            break
        case 10:
            if !floatingPoint {
                progressLabel.text! += "."
                floatingPoint = true
            }
            break
        default:
            break;
        }
        
        allClearButton.setTitle("C", for: .normal)
        
        isProgressLabelEmpty = false
    }
    
    @IBOutlet var operators: [UIButton]!
    @IBAction func inputOperators(_ sender: UIButton) {
        if isProgressLabelEmpty {
            isProgressLabelEmpty = false
            progressLabel.text! = "0"
        }
        
        if progressLabel.text?.last == "+" || progressLabel.text?.last == "-" || progressLabel.text?.last == "×" || progressLabel.text?.last == "÷" {
            progressLabel.text?.removeLast()
        }
        
        resetBuutonColor()
        
        switch operators.index(of: sender)! {
        case 0:
            progressLabel.text! += "+"
            operators[0].backgroundColor = #colorLiteral(red: 0.9764705896, green: 0.850980401, blue: 0.5490196347, alpha: 1)
            break
        case 1:
            progressLabel.text! += "-"
            operators[1].backgroundColor = #colorLiteral(red: 0.9764705896, green: 0.850980401, blue: 0.5490196347, alpha: 1)
            break
        case 2:
            progressLabel.text! += "×"
            operators[2].backgroundColor = #colorLiteral(red: 0.9764705896, green: 0.850980401, blue: 0.5490196347, alpha: 1)
            break
        case 3:
            progressLabel.text! += "÷"
            operators[3].backgroundColor = #colorLiteral(red: 0.9764705896, green: 0.850980401, blue: 0.5490196347, alpha: 1)
            break
        default:
            break
        }
        
        allClearButton.setTitle("AC", for: .normal)
        
        floatingPoint = false
    }
    
    func resetBuutonColor() {
        for button in operators {
            button.backgroundColor = #colorLiteral(red: 0.9807326198, green: 0.5707559586, blue: 0, alpha: 1)
            button.titleLabel?.textColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        }
    }
    
    var isEqualPressed:Bool = false
    @IBAction func equal(_ sender: UIButton) {
        let char:CharacterSet = ["+", "-", "×", "÷"]
        
        if progressLabel.text?.last == "+" || progressLabel.text?.last == "-" {
            progressLabel.text! += "0"
        }
        
        if progressLabel.text?.last == "×" || progressLabel.text?.last == "÷" {
            progressLabel.text! += "1"
        }
        
        var numbersString = progressLabel.text?.components(separatedBy: char)
        var _operators: [Character]! = []
        
        for i in progressLabel.text! {
            if i == "+" || i == "-" || i == "×" || i == "÷" {
                _operators.append(i)
            }
        }
        
        var flag = 0
        for i in 0..._operators.count-1 {
            if _operators[i-flag] == "×" {
                numbersString![i-flag] = String(Float(numbersString![i-flag])! * Float(numbersString![i+1-flag])!)
                numbersString?.remove(at: i+1-flag)
                _operators.remove(at: i-flag)
                flag = flag + 1
            }else if _operators[i-flag] == "÷" {
                numbersString![i-flag] = String(Float(numbersString![i-flag])! / Float(numbersString![i+1-flag])!)
                numbersString?.remove(at: i+1-flag)
                _operators.remove(at: i-flag)
                flag = flag + 1
            }
        }
        
        if _operators.count != 0{
            flag = 0
            for i in 0..._operators.count-1 {
                if _operators[i-flag] == "+" {
                    numbersString![i-flag] = String(Float(numbersString![i-flag])! + Float(numbersString![i+1-flag])!)
                    numbersString?.remove(at: i+1-flag)
                    _operators.remove(at: i-flag)
                    flag = flag + 1
                }else if _operators[i-flag] == "-" {
                    numbersString![i-flag] = String(Float(numbersString![i-flag])! - Float(numbersString![i+1-flag])!)
                    numbersString?.remove(at: i+1-flag)
                    _operators.remove(at: i-flag)
                    flag = flag + 1
                }
            }
        }
        
        while numbersString![0].contains(".") && numbersString![0].last == "0" {
            numbersString![0].removeLast()
        }
        
        if numbersString![0].last == "." {
            numbersString![0].removeLast()
        }
        
        allClearButton.setTitle("AC", for: .normal)
        
        isEqualPressed = true
        if numbersString![0] == "inf" {
            numbersString![0] = "0"
        }
        answer.text = String(numbersString![0])
    }
    
    @IBAction func oppositeSign(_ sender: UIButton) {
        if answer.text?.first != "-" {
            answer.text! = "-" + answer.text!
        }else{
            answer.text?.removeFirst()
        }
    }
    
    @IBOutlet weak var allClearButton: UIButton!
    @IBAction func allClear(_ sender: UIButton) {
        
        if isEqualPressed {
            isProgressLabelEmpty = true
            progressLabel.text = ""
            answer.text = "0"
            floatingPoint = false
            
            resetBuutonColor()
            isEqualPressed = false
            return
        }
        
        if progressLabel.text?.last != "+" && progressLabel.text?.last != "-" && progressLabel.text?.last != "×" && progressLabel.text?.last != "÷" {
            while progressLabel.text?.last != "+" && progressLabel.text?.last != "-" && progressLabel.text?.last != "×" && progressLabel.text?.last != "÷" && progressLabel.text! != "" {
                progressLabel.text?.removeLast()
            }
            
            if progressLabel.text?.last == "+" {
                operators[0].backgroundColor = #colorLiteral(red: 0.9764705896, green: 0.850980401, blue: 0.5490196347, alpha: 1)
            }else if progressLabel.text?.last == "-" {
                operators[1].backgroundColor = #colorLiteral(red: 0.9764705896, green: 0.850980401, blue: 0.5490196347, alpha: 1)
            }else if progressLabel.text?.last == "×" {
                operators[2].backgroundColor = #colorLiteral(red: 0.9764705896, green: 0.850980401, blue: 0.5490196347, alpha: 1)
            }else if progressLabel.text?.last == "÷" {
                operators[3].backgroundColor = #colorLiteral(red: 0.9764705896, green: 0.850980401, blue: 0.5490196347, alpha: 1)
            }
            
            floatingPoint = false
            
            allClearButton.setTitle("AC", for: .normal)
        }else{
            isProgressLabelEmpty = true
            progressLabel.text = ""
            answer.text = "0"
            floatingPoint = false
            
            resetBuutonColor()
            isEqualPressed = false
        }
    }
}
